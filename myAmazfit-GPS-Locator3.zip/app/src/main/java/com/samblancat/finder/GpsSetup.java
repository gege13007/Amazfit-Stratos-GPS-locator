package com.samblancat.finder;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.GpsStatus;
import android.location.LocationManager;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Context;
import android.os.Bundle;

public class GpsSetup extends AppCompatActivity  {
    private BroadcastReceiver receiver;
    public static final String BROADCAST_ACTION = "com.samblancat";
    Context mContext;
    public int main_started = 0;
    LocationManager lm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.waitgpsok);
        mContext = this;

        // on initialise le receiver de service/broadcast
        receiver = new MyReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BROADCAST_ACTION);
        registerReceiver(receiver, intentFilter);

        // on lance le service
        Intent msgIntent = new Intent(mContext, com.samblancat.finder.LocService.class);
        mContext.startService(msgIntent);

        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            lm.addNmeaListener(nmeaListener);
        }
    }

    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
        //Ne stoppe le service que si encore rien reçu !!! -> fermeture anticipée
        if (main_started==0) stopService(new Intent(getBaseContext(), LocService.class));
        unregisterReceiver(receiver);
        lm.removeNmeaListener(nmeaListener);
    }

    public class MyReceiver extends BroadcastReceiver {
        public static final String ACTION_RESP ="com.samblancat";
        private Intent i;
        @Override
        public void onReceive(Context context, Intent intent) {
            //Flag pour assurer un seul Main-activity
            if (main_started==0) {
                main_started = 1;
                i = new Intent(GpsSetup.this, MainActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                finish();
            }
        }
    }

    GpsStatus.NmeaListener nmeaListener = new GpsStatus.NmeaListener() {
        public void onNmeaReceived(long timestamp, String nmea) {
            String[] nmeaSplit = nmea.split(",");
            if (nmeaSplit[0].equalsIgnoreCase("$GPGSV")) {
                //    Toast.makeText(mContext, nmeaSplit[7], Toast.LENGTH_LONG).show();
                TextView txt = (TextView) findViewById(R.id.gsvtxt);
                txt.setText("GSV "+nmeaSplit[2]+"/"+nmeaSplit[1]+"  "+nmeaSplit[3]+" sats");
            }
        }
    };

}
