package com.samblancat.finder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    private BroadcastReceiver receiver;
    public static final String BROADCAST_ACTION = "com.samblancat";
    Context mContext;
    double mylat0=0, mylng0=0;
    double mylat=0, mylng=0;
    SharedPreferences sharedPref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        mContext=this;

        // on initialise le receiver de service/broadcast
        receiver = new MyReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BROADCAST_ACTION);
        registerReceiver(receiver, intentFilter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public void closecmd(View view) {
        unregisterReceiver(receiver);
        stopService(new Intent(getBaseContext(), LocService.class));
        finish();
    }

    //Sauve la Position actuelle pour Recherche Immédiate
    public void setposcmd(View view) {
        //Sauve la Position Départ !
        Intent intent = new Intent(MainActivity.this, Scan.class);
        intent.putExtra("lat0", String.valueOf(mylat));
        intent.putExtra("lng0", String.valueOf(mylng));

        //Start Scanning Finder activity
        startActivity(intent);

        finish();
    }

    public void testjeu(View view) {
        //Lance jeu
        Intent intent = new Intent(MainActivity.this, Scan2.class);
        //Start Jeu Scan2
        startActivity(intent);
        finish();
    }

    public void gotosavedpos(View view) {
        //Récup la position en mém.
        sharedPref = getBaseContext().getSharedPreferences("POSPREFS", MODE_PRIVATE);
        mylat = sharedPref.getFloat("mylat", 0);
        mylng = sharedPref.getFloat("mylng", 0);
        Toast.makeText(this, "Let's go to", Toast.LENGTH_LONG).show();
        String tp = new DecimalFormat("#0.00").format(mylat)+" / "+new DecimalFormat("##0.00").format(mylng);
        Toast.makeText(this, tp, Toast.LENGTH_LONG).show();

        //Sauve la Position Voulue et Go !
        Intent intent = new Intent(MainActivity.this, Scan.class);
        intent.putExtra("lat0", String.valueOf(mylat));
        intent.putExtra("lng0", String.valueOf(mylng));
        //Start scanning
        startActivity(intent);
        finish();
    }

    //Sauve la Position actuelle pour Recherche Future
    public void storepos(View view) {
        //Sauve la Position Départ !
        sharedPref = getBaseContext().getSharedPreferences("POSPREFS", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putFloat("mylat", (float)mylat);
        editor.putFloat("mylng", (float)mylng);
        editor.commit();
        //Store ok !
        Toast.makeText(this, "Position saved!", Toast.LENGTH_LONG).show();
        String tp = new DecimalFormat("#0.00").format(mylat)+" / "+new DecimalFormat("##0.00").format(mylng);
        Toast.makeText(this, tp, Toast.LENGTH_LONG).show();
    }

    public class MyReceiver extends BroadcastReceiver {
        public static final String ACTION_RESP ="com.samblancat";
        @Override
        public void onReceive(Context context, Intent intent) {
            String la,lo;
            la =  intent.getStringExtra("Lat");
            lo = intent.getStringExtra("Lon");
            mylat =  (la!=null)?Double.parseDouble(la):0;
            mylng = (lo!=null)?Double.parseDouble(lo):0;
            double dk=Math.pow(Math.abs(mylat-mylat0),2)+Math.pow(Math.abs(mylng-mylng0),2);
            dk=1000*111.12*Math.sqrt(dk);
            mylat0=mylat;
            mylng0=mylng;
            if (dk<1000) {
                TextView ptxt = (TextView) findViewById(R.id.precistxt);
                String tp = new DecimalFormat("#0.0").format(dk);
                ptxt.setText("Précision "+tp + " m");
            }
        }
    }

}